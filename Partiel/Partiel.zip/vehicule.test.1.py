from vehicule import * 
foo = Vehicule() 
bar = Vehicule("BMW Série 2", 1350, 55) 
print(foo)
print(bar)