from vehicule import VoitureDiesel, VoitureEssence
foo = VoitureEssence("Yaris pourrie", 950, 42)
bar = VoitureDiesel("BMW Série 2", 1350, 55)
foo.Accelerer()
foo.Accelerer()
bar.Accelerer()
bar.Accelerer()
print(foo)
print(bar)